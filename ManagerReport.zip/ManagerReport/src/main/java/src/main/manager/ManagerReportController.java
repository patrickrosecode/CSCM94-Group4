package src.main.manager;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * @Author Christian Piri
 * @Version v1.0
 */

public class ManagerReportController {
    @FXML
    private Label currentDisplay;
    @FXML
    private javafx.scene.control.Button btnCurrentSitting;
    @FXML
    private javafx.scene.control.Button btnExit;

    @FXML
    protected void changeLabel(ActionEvent e) {
        currentDisplay.setText("Current Sitting");
    }
    @FXML
    protected void closeCW (ActionEvent e) {
        Stage stage = (Stage) btnExit.getScene().getWindow();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to exit?",
                ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
        alert.showAndWait();

        if (alert.getResult() == ButtonType.YES) {
            stage.close();
        }
    }

}