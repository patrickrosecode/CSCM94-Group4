package src.main.manager;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.sql.*;

import java.io.IOException;

public class ManagerReportApp extends Application {
    @Override
    /**
     * Initial Stage
     */
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(ManagerReportApp.class.getResource("managerReportFXML.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 750, 750);
        stage.setTitle("Manager Report");
        stage.setMaximized(true);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Tests/Connects to SQL database
     */
    public static void sqlConnection() {
        String username = "root";
        String password = "";
        String query = "select * from users";
        String url = "jdbc:mysql://localhost:3306/SocialNetwork";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            Connection con = DriverManager.getConnection(url, username, password);
            Statement statement = con.createStatement();
            ResultSet result = statement.executeQuery(query);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        sqlConnection();
        launch();

    }
}