package src.main.manager;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import org.w3c.dom.Text;

import java.sql.*;
import static javafx.scene.paint.Color.*;

/**
 * @Author Christian Piri
 * @Version v1.1
 */

public class ManagerReportController {
    @FXML
    private Label cDisplay, sqlConnectionText, cSittingText;
    @FXML
    private Circle circleConnection;
    @FXML
    private javafx.scene.control.Button btnExit, btnTodaysSitting,
            btnConnect, btnShowMenu, btnStaff;
    @FXML
    private TableView<Users> tblData;
    @FXML
    private TableColumn<Users, String> columnOne;
    @FXML
    private TableColumn<Users, String> columnTwo;
    @FXML
    private TableColumn<Users, String> columnThree;
    @FXML
    private TableColumn<Users, String> columnFour;
    @FXML
    private TableColumn<Users, String> columnFive;
    @FXML
    private TableColumn<Users, String> columnSix;

    Connection con = null;
    String queryCurrentMenu = "SELECT * FROM users";
    String queryStaff = "SELECT * FROM links";
    String queryTodaysSitting = "SELECT * FROM Number_Sitting";
    ObservableList<Users> data = FXCollections.observableArrayList();

    @FXML
    protected void showCurrentMenu(ActionEvent e) throws SQLException {
        columnOne.setText("User ID");
        columnTwo.setText("Username");
        columnThree.setText("Password");
        columnFour.setText("Email");
        columnFive.setText("Type");
        columnSix.setText("Login Date");

        tblData.getItems().clear();
        setCellTable();
        loadDataMenu();
    }

    @FXML
    protected void showStaff(ActionEvent e) throws SQLException {
        columnOne.setText("User ID");
        columnTwo.setText("Username");
        columnThree.setText("Password");
        columnFour.setText("Email");
        columnFive.setText("Type");
        columnSix.setText("Login Date");

        tblData.getItems().clear();
        setCellTable();
        loadDataStaff();
    }

    @FXML
    protected void todaysSitting(ActionEvent e) throws SQLException {
        loadDataTS();
    }

    /**
     * Connects to database and activates all buttons.
     * @throws SQLException
     */
    @FXML
    protected void connectSQL () throws SQLException{
        con = DBConnector.getConnection();
        circleConnection.setFill(GREEN);
        sqlConnectionText.setText("SQL Database Connection: Active");

        btnShowMenu.setDisable(false);
        btnTodaysSitting.setDisable(false);
        btnStaff.setDisable(false);
    }

    @FXML
    protected void closeCW (ActionEvent e) {
        Stage stage = (Stage) btnExit.getScene().getWindow();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to exit?",
                ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
        alert.showAndWait();

        if (alert.getResult() == ButtonType.YES) {
            stage.close();
        }
    }

    /**
     * Assigns cells a value for data to pointed at.
     */
    private void setCellTable () {
        columnOne.setCellValueFactory(new PropertyValueFactory<>("columnOne"));
        columnTwo.setCellValueFactory(new PropertyValueFactory<>("columnTwo"));
        columnThree.setCellValueFactory(new PropertyValueFactory<>("columnThree"));
        columnFour.setCellValueFactory(new PropertyValueFactory<>("columnFour"));
        columnFive.setCellValueFactory(new PropertyValueFactory<>("columnFive"));
        columnSix.setCellValueFactory(new PropertyValueFactory<>("columnSix"));
    }


    private void loadDataMenu () throws SQLException {
        ResultSet resultSet = con.createStatement().executeQuery(queryCurrentMenu);

        while (resultSet.next()) {
            data.add(new Users(resultSet.getString(1),
                    resultSet.getString(2), resultSet.getString(3),
                    resultSet.getString(4), resultSet.getString(5),
                    resultSet.getString(6)));
        }
        tblData.setItems(data);
    }

    private void loadDataStaff () throws SQLException {
        ResultSet resultSet = con.createStatement().executeQuery(queryStaff);

        while (resultSet.next()) {
            data.add(new Users(resultSet.getString(1),
                    resultSet.getString(2), resultSet.getString(3),
                    resultSet.getString(4), resultSet.getString(5),
                    resultSet.getString(6)));
        }
        tblData.setItems(data);
    }

    /**
     * Collects count on number of bookings.
     *
     * @throws SQLException
     */
    private void loadDataTS () throws SQLException {
        ResultSet resultSet = con.createStatement().executeQuery(queryTodaysSitting);
        String sitting = null;

        while (resultSet.next()) {
            sitting = "";
            sitting += resultSet.getString(1);
        }
        cSittingText.setText(sitting);

    }

}