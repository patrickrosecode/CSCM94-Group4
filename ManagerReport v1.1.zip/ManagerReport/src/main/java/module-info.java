module src.main.manager {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens src.main.manager to javafx.fxml;
    exports src.main.manager;
}